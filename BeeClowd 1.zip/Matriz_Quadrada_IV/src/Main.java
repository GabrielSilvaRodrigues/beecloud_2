import java.io.IOException;
import java.util.Scanner;
public class Main {
    public static void main(String[] args) throws IOException {
        Scanner sc = new Scanner(System.in);
        while (sc.hasNextInt()) {
            int N = sc.nextInt();
            int[][] matrix = new int[N][N];
            int center = N / 2; 
            int start = N / 3; 
            int end = N - start - 1;
            for (int i = 0; i < N; i++) {
                for (int j = 0; j < N; j++) {
                    if (i == j) matrix[i][j] = 2; 
                    if (i + j == N - 1) matrix[i][j] = 3;
                    if (i >= start && i <= end && j >= start && j <= end) matrix[i][j] = 1;
                    if (i == center && j == center) matrix[i][j] = 4;
                }
            }
            for (int i = 0; i < N; i++) {
                for (int j = 0; j < N; j++) {
                    System.out.print(matrix[i][j]);
                }
                System.out.println();
            }
            System.out.println();
        }
        sc.close();
    }
}